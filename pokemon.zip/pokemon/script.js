document.addEventListener('DOMContentLoaded', () => {
    const resultsDiv = document.getElementById('results');

    // Fetch data from Mercado Libre API
    fetch('https://api.mercadolibre.com/sites/MLA/search?q=ordenadores')
        .then(response => response.json())
        .then(data => {
            displayResults(data.results, 'Mercado Libre Results');
        })
        .catch(error => console.error('Error fetching Mercado Libre data:', error));

    // Fetch data from PokeAPI
    fetch('https://pokeapi.co/api/v2/pokemon/ditto')
        .then(response => response.json())
        .then(data => {
            displayPokemon(data);
        })
        .catch(error => console.error('Error fetching PokeAPI data:', error));

    function displayResults(items, title) {
        const section = document.createElement('section');
        section.classList.add('my-4');

        const header = document.createElement('h2');
        header.textContent = title;
        section.appendChild(header);

        const list = document.createElement('ul');
        list.classList.add('list-group');
        items.forEach(item => {
            const listItem = document.createElement('li');
            listItem.classList.add('list-group-item');
            listItem.textContent = item.title;
            list.appendChild(listItem);
        });
        section.appendChild(list);
        resultsDiv.appendChild(section);
    }

    function displayPokemon(pokemon) {
        const section = document.createElement('section');
        section.classList.add('my-4');

        const header = document.createElement('h2');
        header.textContent = 'PokeAPI Results';
        section.appendChild(header);

        const div = document.createElement('div');
        div.classList.add('card', 'p-3');
        div.innerHTML = `<h3>${pokemon.name}</h3>
                         <p>Height: ${pokemon.height}</p>
                         <p>Weight: ${pokemon.weight}</p>
                         <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">`;
        section.appendChild(div);
        resultsDiv.appendChild(section);
    }
});
